
Function global:TabExpansion {
    param($Line, $LastWord)

    Invoke-TabExpansion -Line $Line -LastWord $LastWord
}